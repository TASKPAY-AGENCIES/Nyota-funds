# ⭐ Nyota Funds Kenya

A humanitarian grant platform with M-Pesa STK Push payments via Paylor.

---

## 🗂️ Project Structure

```
nyota-funds/
├── frontend/   → React + Vite + Tailwind (deploy to Vercel)
└── backend/    → Node + Express (deploy to Render)
```

---

## 🚀 Setup

### Frontend
```bash
cd frontend
npm install
cp .env.example .env       # Add your backend URL
npm run dev                # Local dev
npm run build              # Build for production
```

### Backend
```bash
cd backend
npm install
cp .env.example .env       # Add your Paylor API key
node server.js             # Start server
```

---

## 🔑 Environment Variables

### Frontend (`frontend/.env`)
```
VITE_BACKEND_URL=https://your-backend.onrender.com
```

### Backend (`backend/.env`)
```
PAYLOR_API_KEY=your_paylor_api_key_here
BACKEND_URL=https://your-backend.onrender.com
FRONTEND_URL=https://your-frontend.vercel.app
```

---

## 📦 Deploying

### Vercel (Frontend)
1. Push to GitHub
2. Import repo on vercel.com
3. Set root directory: `frontend`
4. Add env variable: `VITE_BACKEND_URL`

### Render (Backend)
1. Create a new Web Service on render.com
2. Set root directory: `backend`
3. Start command: `node server.js`
4. Add env variables from `.env.example`

---

## 💳 Paylor Integration

1. Log in to app.paylorke.com
2. Go to Developer / API section
3. Copy your API Key → paste into backend `.env`
4. Check Paylor docs for exact STK Push endpoint and callback field names
5. Update `backend/server.js` line 30 with correct endpoint

---

## ⚠️ Notes

- Payments are stored in memory (server restart clears them). This is fine for small use.
- The backend URL in `server.js` callback must be publicly accessible (not localhost).
- Test with Paylor sandbox first before going live.
