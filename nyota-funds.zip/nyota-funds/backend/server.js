require('dotenv').config();
const express = require('express');
const cors = require('cors');
const axios = require('axios');

const app = express();
const PORT = process.env.PORT || 3001;

// In-memory payment tracker (no database needed)
const payments = {};

app.use(cors({
  origin: process.env.FRONTEND_URL || '*',
  credentials: true,
}));
app.use(express.json());

// ==========================================
// PAYLOR STK PUSH
// ==========================================

/**
 * POST /api/pay
 * Triggers M-Pesa STK Push via Paylor API
 */
app.post('/api/pay', async (req, res) => {
  const { phone, amount, grantAmount, applicantName, idNumber, county, purpose } = req.body;

  if (!phone || !amount) {
    return res.status(400).json({ success: false, message: 'Phone and amount are required.' });
  }

  try {
    // ---- PAYLOR STK PUSH REQUEST ----
    // Replace with actual Paylor API endpoint from their docs
    const paylorResponse = await axios.post(
      'https://api.paylorke.com/v1/stk-push', // <-- Check Paylor docs for exact endpoint
      {
        phone_number: phone,
        amount: amount,
        account_reference: `NYOTA-${Date.now()}`,
        transaction_desc: `Nyota Funds Grant Application - KES ${grantAmount}`,
        callback_url: `${process.env.BACKEND_URL}/api/pay/callback`,
      },
      {
        headers: {
          'Authorization': `Bearer ${process.env.PAYLOR_API_KEY}`,
          'Content-Type': 'application/json',
        },
      }
    );

    const checkoutRequestId = paylorResponse.data.checkout_request_id || paylorResponse.data.CheckoutRequestID;

    // Store application data temporarily
    payments[checkoutRequestId] = {
      status: 'pending',
      applicantName,
      idNumber,
      phone,
      county,
      purpose,
      grantAmount,
      fee: amount,
      createdAt: new Date().toISOString(),
    };

    return res.json({ success: true, checkoutRequestId });

  } catch (err) {
    console.error('Paylor STK Push error:', err?.response?.data || err.message);
    return res.status(500).json({
      success: false,
      message: 'Failed to initiate payment. Please try again.',
    });
  }
});

/**
 * POST /api/pay/callback
 * Paylor sends payment result here (webhook)
 */
app.post('/api/pay/callback', (req, res) => {
  console.log('Paylor callback received:', JSON.stringify(req.body, null, 2));

  // Paylor callback body — adjust field names to match actual Paylor docs
  const { checkout_request_id, result_code, result_desc } = req.body;

  const checkoutId = checkout_request_id || req.body.CheckoutRequestID;

  if (checkoutId && payments[checkoutId]) {
    if (result_code === 0 || result_code === '0') {
      payments[checkoutId].status = 'completed';
      console.log(`✅ Payment confirmed for ${payments[checkoutId].applicantName}`);
    } else {
      payments[checkoutId].status = 'failed';
      console.log(`❌ Payment failed: ${result_desc}`);
    }
  }

  res.json({ ResultCode: 0, ResultDesc: 'Accepted' });
});

/**
 * GET /api/pay/status/:checkoutRequestId
 * Frontend polls this to check payment status
 */
app.get('/api/pay/status/:id', (req, res) => {
  const payment = payments[req.params.id];
  if (!payment) {
    return res.json({ status: 'not_found' });
  }
  res.json({ status: payment.status });
});

// Health check
app.get('/', (req, res) => res.json({ message: 'Nyota Funds Backend Running ✅' }));

app.listen(PORT, () => console.log(`🌟 Nyota Funds backend running on port ${PORT}`));
