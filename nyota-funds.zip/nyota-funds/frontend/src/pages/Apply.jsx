import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import Step1Personal from '../components/Step1Personal';
import Step2Purpose from '../components/Step2Purpose';
import Step3Grant from '../components/Step3Grant';
import Step4Payment from '../components/Step4Payment';

const STEPS = [
  { num: 1, label: 'Personal Info', icon: '👤' },
  { num: 2, label: 'Grant Purpose', icon: '📋' },
  { num: 3, label: 'Select Grant', icon: '💎' },
  { num: 4, label: 'Payment', icon: '📱' },
];

export default function Apply() {
  const navigate = useNavigate();
  const location = useLocation();
  const [step, setStep] = useState(1);
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    selectedTier: location.state?.selectedTier || null,
  });

  const validateStep = () => {
    if (step === 1) {
      return formData.fullName && formData.idNumber && formData.phone && formData.dob && formData.county && formData.occupation;
    }
    if (step === 2) return formData.purpose && formData.description;
    if (step === 3) return formData.selectedTier;
    return true;
  };

  const next = () => {
    if (!validateStep()) {
      alert('Please fill in all required fields before continuing.');
      return;
    }
    setStep(s => Math.min(s + 1, 4));
  };

  const back = () => setStep(s => Math.max(s - 1, 1));

  if (submitted) {
    return (
      <div className="min-h-screen bg-nyota-dark flex items-center justify-center px-6">
        <div className="text-center animate-fade-in">
          <div className="text-7xl mb-6 animate-float">🌟</div>
          <h1 className="font-display text-4xl text-purple-100 font-bold mb-4">Asante Sana!</h1>
          <p className="text-purple-300 text-lg mb-2">Your application has been received.</p>
          <p className="text-purple-500 mb-8">We will review your application and disburse your grant within 24 hours via M-Pesa.</p>
          <button onClick={() => navigate('/')} className="btn-primary">
            Back to Home
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-nyota-dark relative">
      {/* Ambient glows */}
      <div className="fixed top-0 left-0 w-96 h-96 bg-purple-900/20 rounded-full blur-3xl pointer-events-none" />
      <div className="fixed bottom-0 right-0 w-80 h-80 bg-violet-900/15 rounded-full blur-3xl pointer-events-none" />

      {/* Navbar */}
      <nav className="relative z-10 flex items-center justify-between px-6 py-5 border-b border-purple-900/30">
        <button onClick={() => navigate('/')} className="flex items-center gap-2 text-purple-400 hover:text-purple-200 transition-colors">
          ← <span className="text-sm">Back</span>
        </button>
        <div className="flex items-center gap-2">
          <span className="text-xl">⭐</span>
          <span className="font-display font-bold text-purple-100">Nyota Funds</span>
        </div>
        <div className="w-16" />
      </nav>

      <div className="relative z-10 max-w-2xl mx-auto px-6 py-10">
        <div className="text-center mb-10">
          <h1 className="font-display text-3xl text-purple-100 font-bold mb-2">Grant Application</h1>
          <p className="text-purple-400 text-sm">Step {step} of 4 — {STEPS[step - 1].label}</p>
        </div>

        {/* Stepper */}
        <div className="flex items-center justify-between mb-10">
          {STEPS.map((s, idx) => (
            <React.Fragment key={s.num}>
              <div className="flex flex-col items-center gap-1">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold transition-all duration-300 ${
                  step > s.num ? 'bg-purple-600 text-white'
                  : step === s.num ? 'bg-gradient-to-br from-purple-600 to-violet-600 text-white shadow-lg shadow-purple-900/50 animate-pulse-glow'
                  : 'bg-purple-900/40 text-purple-500 border border-purple-800/40'
                }`}>
                  {step > s.num ? '✓' : s.icon}
                </div>
                <span className={`text-xs hidden md:block ${step === s.num ? 'text-purple-200' : 'text-purple-600'}`}>
                  {s.label}
                </span>
              </div>
              {idx < STEPS.length - 1 && (
                <div className={`flex-1 h-0.5 mx-2 transition-all duration-500 ${step > s.num ? 'bg-purple-600' : 'bg-purple-900/40'}`} />
              )}
            </React.Fragment>
          ))}
        </div>

        {/* Form card */}
        <div className="card-glass p-6 md:p-8">
          {step === 1 && <Step1Personal data={formData} onChange={setFormData} />}
          {step === 2 && <Step2Purpose data={formData} onChange={setFormData} />}
          {step === 3 && <Step3Grant data={formData} onChange={setFormData} />}
          {step === 4 && (
            <Step4Payment
              data={formData}
              onChange={setFormData}
              onSuccess={() => setSubmitted(true)}
            />
          )}
        </div>

        {/* Navigation buttons */}
        {step < 4 && (
          <div className="flex gap-4 mt-6">
            {step > 1 && (
              <button
                onClick={back}
                className="flex-1 border border-purple-800/50 text-purple-400 py-3 rounded-xl hover:border-purple-600 hover:text-purple-200 transition-all duration-300"
              >
                ← Previous
              </button>
            )}
            <button
              onClick={next}
              className="flex-1 btn-primary text-center"
            >
              {step === 3 ? 'Proceed to Payment →' : 'Continue →'}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
