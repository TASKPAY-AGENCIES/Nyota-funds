import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { TESTIMONIALS, GRANT_TIERS } from '../data';

const StarField = () => (
  <div className="absolute inset-0 overflow-hidden pointer-events-none">
    {[...Array(80)].map((_, i) => (
      <div
        key={i}
        className="absolute rounded-full"
        style={{
          width: Math.random() > 0.8 ? '2px' : '1px',
          height: Math.random() > 0.8 ? '2px' : '1px',
          top: `${Math.random() * 100}%`,
          left: `${Math.random() * 100}%`,
          background: Math.random() > 0.5 ? 'rgba(168,85,247,0.8)' : 'rgba(255,255,255,0.6)',
          animation: `pulse ${2 + Math.random() * 4}s ease-in-out infinite`,
          animationDelay: `${Math.random() * 4}s`,
        }}
      />
    ))}
  </div>
);

const TestimonialCard = ({ t }) => (
  <div className="flex-shrink-0 w-72 card-glass p-5 mx-3">
    <div className="flex items-center gap-3 mb-3">
      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-600 to-violet-800 flex items-center justify-center text-white font-bold text-sm">
        {t.name.charAt(0)}
      </div>
      <div>
        <p className="text-purple-100 font-semibold text-sm">{t.name}</p>
        <p className="text-purple-400 text-xs">{t.county} County</p>
      </div>
      <div className="ml-auto text-right">
        <p className="text-nyota-gold font-bold text-sm">KES {t.amount.toLocaleString()}</p>
        <div className="flex gap-0.5 justify-end">
          {[...Array(5)].map((_, i) => <span key={i} className="text-nyota-gold text-xs">★</span>)}
        </div>
      </div>
    </div>
    <p className="text-purple-300 text-sm leading-relaxed italic">"{t.message}"</p>
  </div>
);

export default function Landing() {
  const navigate = useNavigate();
  const [count, setCount] = useState({ grants: 0, amount: 0, members: 0 });

  useEffect(() => {
    const targets = { grants: 2847, amount: 142, members: 3200 };
    const duration = 2000;
    const steps = 60;
    let step = 0;
    const timer = setInterval(() => {
      step++;
      const progress = step / steps;
      const ease = 1 - Math.pow(1 - progress, 3);
      setCount({
        grants: Math.floor(targets.grants * ease),
        amount: Math.floor(targets.amount * ease),
        members: Math.floor(targets.members * ease),
      });
      if (step >= steps) clearInterval(timer);
    }, duration / steps);
    return () => clearInterval(timer);
  }, []);

  const doubled = [...TESTIMONIALS, ...TESTIMONIALS];

  return (
    <div className="min-h-screen bg-nyota-dark relative overflow-hidden">
      <StarField />

      {/* Ambient glows */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-purple-900/20 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute top-1/3 right-0 w-80 h-80 bg-violet-900/15 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 left-0 w-72 h-72 bg-purple-900/10 rounded-full blur-3xl pointer-events-none" />

      {/* Navbar */}
      <nav className="relative z-10 flex items-center justify-between px-6 py-5 max-w-6xl mx-auto">
        <div className="flex items-center gap-2">
          <span className="text-2xl">⭐</span>
          <span className="font-display font-bold text-xl text-purple-100">Nyota Funds</span>
          <span className="text-purple-400 text-sm ml-1">Kenya</span>
        </div>
        <button
          onClick={() => navigate('/apply')}
          className="btn-primary text-sm px-6 py-2.5"
        >
          Apply Now
        </button>
      </nav>

      {/* Hero */}
      <section className="relative z-10 text-center px-6 pt-16 pb-20 max-w-4xl mx-auto animate-fade-in">
        <div className="inline-flex items-center gap-2 bg-purple-900/30 border border-purple-700/40 rounded-full px-4 py-2 mb-8">
          <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
          <span className="text-purple-300 text-sm">Applications Open — Limited Slots</span>
        </div>

        <h1 className="font-display text-5xl md:text-7xl font-bold leading-tight mb-6">
          <span className="text-purple-100">Taa ya </span>
          <span className="bg-gradient-to-r from-purple-400 via-violet-400 to-purple-300 bg-clip-text text-transparent">
            Matumaini
          </span>
        </h1>
        <p className="text-xl text-purple-300 mb-4 font-light">
          A Star of Hope for Every Kenyan
        </p>
        <p className="text-purple-400 max-w-2xl mx-auto mb-10 leading-relaxed">
          Nyota Funds Kenya provides humanitarian grants from <strong className="text-purple-200">KES 22,500</strong> to <strong className="text-purple-200">KES 105,000</strong> directly to your M-Pesa. Apply in minutes. Receive within 24 hours.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
          <button onClick={() => navigate('/apply')} className="btn-primary text-lg animate-pulse-glow">
            Apply for a Grant ✦
          </button>
          <button
            onClick={() => document.getElementById('how-it-works').scrollIntoView({ behavior: 'smooth' })}
            className="border border-purple-700/50 text-purple-300 px-8 py-4 rounded-xl hover:border-purple-500 hover:text-purple-100 transition-all duration-300"
          >
            How It Works
          </button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-6 max-w-2xl mx-auto">
          {[
            { value: count.grants.toLocaleString(), label: "Grants Awarded", suffix: "+" },
            { value: `${count.amount}M`, label: "KES Disbursed", suffix: "+" },
            { value: count.members.toLocaleString(), label: "Members Helped", suffix: "+" },
          ].map((stat, i) => (
            <div key={i} className="card-glass p-4">
              <p className="text-2xl md:text-3xl font-bold text-purple-100">{stat.value}{stat.suffix}</p>
              <p className="text-purple-400 text-xs mt-1">{stat.label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Testimonials marquee */}
      <section className="relative z-10 py-12 overflow-hidden">
        <p className="text-center text-purple-400 text-sm mb-6 tracking-widest uppercase">What Our Members Say</p>
        <div className="flex">
          <div className="flex marquee-track">
            {doubled.map((t, i) => <TestimonialCard key={i} t={t} />)}
          </div>
        </div>
      </section>

      {/* Grant Tiers */}
      <section className="relative z-10 px-6 py-16 max-w-6xl mx-auto">
        <h2 className="font-display text-3xl text-center text-purple-100 mb-3">Choose Your Grant</h2>
        <p className="text-center text-purple-400 mb-10">Select the amount that fits your need</p>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {GRANT_TIERS.map((tier) => (
            <div
              key={tier.id}
              onClick={() => navigate('/apply', { state: { selectedTier: tier } })}
              className="card-glass p-4 cursor-pointer hover:border-purple-500/60 transition-all duration-300 group hover:-translate-y-1"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-purple-400 text-xs uppercase tracking-wide">{tier.label}</span>
                {tier.id === 12 && <span className="text-xs bg-nyota-gold/20 text-nyota-gold px-2 py-0.5 rounded-full">Top</span>}
              </div>
              <p className="text-purple-100 font-bold text-xl group-hover:text-purple-300 transition-colors">
                KES {tier.amount.toLocaleString()}
              </p>
              <p className="text-purple-500 text-xs mt-1">Fee: KES {tier.fee}</p>
            </div>
          ))}
        </div>
      </section>

      {/* How it works */}
      <section id="how-it-works" className="relative z-10 px-6 py-16 max-w-4xl mx-auto">
        <h2 className="font-display text-3xl text-center text-purple-100 mb-12">How It Works</h2>
        <div className="grid md:grid-cols-4 gap-6">
          {[
            { step: "1", icon: "📝", title: "Fill Application", desc: "Enter your personal details and grant purpose in our simple form." },
            { step: "2", icon: "💎", title: "Select Grant", desc: "Choose the grant amount that fits your current need." },
            { step: "3", icon: "📱", title: "Pay Small Fee", desc: "Pay your registration fee via M-Pesa STK Push — direct to your phone." },
            { step: "4", icon: "🌟", title: "Receive Funds", desc: "Grant disbursed to your M-Pesa within 24 hours of approval." },
          ].map((item) => (
            <div key={item.step} className="text-center">
              <div className="w-16 h-16 card-glass rounded-2xl flex items-center justify-center text-3xl mx-auto mb-4 animate-float" style={{ animationDelay: `${parseInt(item.step) * 0.3}s` }}>
                {item.icon}
              </div>
              <h3 className="text-purple-100 font-semibold mb-2">{item.title}</h3>
              <p className="text-purple-400 text-sm leading-relaxed">{item.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="relative z-10 px-6 py-16 text-center">
        <div className="card-glass max-w-2xl mx-auto p-10">
          <span className="text-4xl mb-4 block">⭐</span>
          <h2 className="font-display text-3xl text-purple-100 mb-4">Ready to Apply?</h2>
          <p className="text-purple-400 mb-8">Join thousands of Kenyans who have received support through Nyota Funds.</p>
          <button onClick={() => navigate('/apply')} className="btn-primary text-lg">
            Start Application →
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer className="relative z-10 border-t border-purple-900/40 px-6 py-8 text-center">
        <div className="flex items-center justify-center gap-2 mb-3">
          <span className="text-xl">⭐</span>
          <span className="font-display font-bold text-purple-100">Nyota Funds Kenya</span>
        </div>
        <p className="text-purple-500 text-sm">Empowering communities, one grant at a time.</p>
        <p className="text-purple-600 text-xs mt-3">© {new Date().getFullYear()} Nyota Funds Kenya. All rights reserved.</p>
      </footer>
    </div>
  );
}
