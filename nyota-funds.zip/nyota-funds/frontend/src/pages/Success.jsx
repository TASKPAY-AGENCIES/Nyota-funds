import { useLocation, Link } from 'react-router-dom'
import { useEffect, useState } from 'react'
import axios from 'axios'

export default function Success() {
  const { state } = useLocation()
  const [status, setStatus] = useState('pending') // pending | confirmed | failed
  const phone = state?.phone
  const tier = state?.tier

  useEffect(() => {
    if (!state?.paymentId) return
    const interval = setInterval(async () => {
      try {
        const res = await axios.get(`/api/pay/status/${state.paymentId}`)
        if (res.data.status === 'confirmed') {
          setStatus('confirmed')
          clearInterval(interval)
        } else if (res.data.status === 'failed') {
          setStatus('failed')
          clearInterval(interval)
        }
      } catch {
        // keep polling
      }
    }, 3000)
    return () => clearInterval(interval)
  }, [state])

  return (
    <div className="min-h-screen flex items-center justify-center px-4" style={{ background: 'linear-gradient(135deg, #1a0a2e 0%, #16023a 50%, #0d001f 100%)' }}>
      <div className="glass rounded-3xl p-10 max-w-md w-full text-center">
        <div className="w-20 h-20 rounded-full bg-green-500/20 border-2 border-green-500 flex items-center justify-center mx-auto mb-6">
          <span className="text-4xl">✓</span>
        </div>
        <h1 className="text-3xl font-bold text-white mb-3">Application Submitted!</h1>
        <p className="text-gray-300 mb-6">
          Check your phone <strong className="text-white">{phone}</strong> for the M-Pesa STK Push prompt and enter your PIN to complete payment.
        </p>

        {tier && (
          <div className="bg-purple-900/30 border border-purple-500/30 rounded-2xl p-5 mb-6 text-left space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-gray-400">Grant Applied For</span>
              <span className="text-green-400 font-bold">KES {tier.amount.toLocaleString()}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-400">Fee Paid</span>
              <span className="text-white font-medium">KES {tier.fee}</span>
            </div>
          </div>
        )}

        {status === 'pending' && (
          <p className="text-purple-300 text-sm animate-pulse mb-6">⏳ Waiting for payment confirmation...</p>
        )}
        {status === 'confirmed' && (
          <p className="text-green-400 text-sm font-semibold mb-6">✅ Payment confirmed! Your application is under review.</p>
        )}
        {status === 'failed' && (
          <p className="text-red-400 text-sm mb-6">❌ Payment was not completed. Please try again.</p>
        )}

        <Link to="/" className="text-purple-400 hover:text-purple-300 text-sm transition">
          ← Back to Home
        </Link>
      </div>
    </div>
  )
}
