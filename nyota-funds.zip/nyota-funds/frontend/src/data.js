export const GRANT_TIERS = [
  { id: 1, amount: 22500, fee: 375, label: "Starter" },
  { id: 2, amount: 27500, fee: 415, label: "Basic" },
  { id: 3, amount: 30500, fee: 525, label: "Essential" },
  { id: 4, amount: 35500, fee: 645, label: "Support" },
  { id: 5, amount: 40500, fee: 705, label: "Relief" },
  { id: 6, amount: 55000, fee: 755, label: "Standard" },
  { id: 7, amount: 60000, fee: 815, label: "Growth" },
  { id: 8, amount: 75000, fee: 875, label: "Advance" },
  { id: 9, amount: 80000, fee: 935, label: "Premier" },
  { id: 10, amount: 85000, fee: 995, label: "Elite" },
  { id: 11, amount: 90000, fee: 1135, label: "Platinum" },
  { id: 12, amount: 105000, fee: 1335, label: "Diamond" },
];

export const COUNTIES = [
  "Baringo","Bomet","Bungoma","Busia","Elgeyo-Marakwet","Embu","Garissa",
  "Homa Bay","Isiolo","Kajiado","Kakamega","Kericho","Kiambu","Kilifi",
  "Kirinyaga","Kisii","Kisumu","Kitui","Kwale","Laikipia","Lamu","Machakos",
  "Makueni","Mandera","Marsabit","Meru","Migori","Mombasa","Murang'a",
  "Nairobi","Nakuru","Nandi","Narok","Nyamira","Nyandarua","Nyeri",
  "Samburu","Siaya","Taita Taveta","Tana River","Tharaka Nithi","Trans Nzoia",
  "Turkana","Uasin Gishu","Vihiga","Wajir","West Pokot"
];

export const OCCUPATIONS = [
  "Healthcare Worker","Teacher / Educator","Casual Labourer","Small Business Owner / Vendor",
  "Hair Stylist / Barber","Boda Boda Rider","Clergy / Pastor / Sheikh","Subsistence Farmer",
  "Technician","Police / Military / Retired","Student","Unemployed","Other"
];

export const GRANT_PURPOSES = [
  "Education & School Fees",
  "Starting or Expanding a Business",
  "Medical Emergency",
  "Housing & Rent",
  "Agricultural Support",
  "Funeral & Burial Expenses",
  "Food & Basic Needs",
  "Other"
];

export const TESTIMONIALS = [
  { name: "Wanjiku M.", county: "Kiambu", amount: 40500, message: "Nilipata pesa ndani ya siku moja. Nimeweza kulipa ada ya mtoto wangu." },
  { name: "Otieno J.", county: "Kisumu", amount: 60000, message: "Nyota Funds ilinisaidia kufungua duka langu. Asante sana!" },
  { name: "Fatuma A.", county: "Mombasa", amount: 27500, message: "Nilikuwa na shida kubwa. Nyota Funds ilinipa tumaini jipya." },
  { name: "Kamau P.", county: "Nakuru", amount: 85000, message: "Niliomba asubuhi, pesa ilikuwa kwa simu yangu jioni. Mungu awabariki." },
  { name: "Akinyi R.", county: "Homa Bay", amount: 35500, message: "Process ilikuwa rahisi sana. Niliapply phone yangu tu." },
  { name: "Mwangi T.", county: "Murang'a", amount: 55000, message: "Biashara yangu ilikuwa inakufa. Nyota Funds ilinisaidia kuirejesha." },
  { name: "Halima S.", county: "Garissa", amount: 22500, message: "Watoto wangu wameweza kurudi shule. Asante Nyota Funds Kenya!" },
  { name: "Ochieng B.", county: "Siaya", amount: 75000, message: "Nilikuwa nahitaji pesa ya hospitali. Walinijibu haraka sana." },
  { name: "Njeri W.", county: "Nyeri", amount: 30500, message: "Nimeweza kununua ng'ombe wa maziwa. Maisha yanabadilika polepole." },
  { name: "Baraka L.", county: "Kilifi", amount: 105000, message: "Grant ya Diamond ilibadilisha maisha yangu kabisa. Nashukuru sana." },
];
