import React from 'react';
import { COUNTIES, OCCUPATIONS } from '../data';

export default function Step1Personal({ data, onChange }) {
  const handle = (e) => onChange({ ...data, [e.target.name]: e.target.value });

  return (
    <div className="space-y-5 animate-slide-up">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        <div>
          <label className="block text-purple-300 text-sm mb-2">Full Name *</label>
          <input
            name="fullName"
            value={data.fullName || ''}
            onChange={handle}
            placeholder="Enter your full name"
            className="input-field"
            required
          />
        </div>
        <div>
          <label className="block text-purple-300 text-sm mb-2">ID / Passport Number *</label>
          <input
            name="idNumber"
            value={data.idNumber || ''}
            onChange={handle}
            placeholder="National ID or Passport No."
            className="input-field"
            required
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        <div>
          <label className="block text-purple-300 text-sm mb-2">Phone Number (M-Pesa) *</label>
          <input
            name="phone"
            value={data.phone || ''}
            onChange={handle}
            placeholder="07XX XXX XXX or 01XX XXX XXX"
            className="input-field"
            type="tel"
            required
          />
        </div>
        <div>
          <label className="block text-purple-300 text-sm mb-2">Date of Birth *</label>
          <input
            name="dob"
            value={data.dob || ''}
            onChange={handle}
            className="input-field"
            type="date"
            required
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        <div>
          <label className="block text-purple-300 text-sm mb-2">County *</label>
          <div className="relative">
            <select name="county" value={data.county || ''} onChange={handle} className="select-field" required>
              <option value="">Select County</option>
              {COUNTIES.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
            <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-purple-400">▾</div>
          </div>
        </div>
        <div>
          <label className="block text-purple-300 text-sm mb-2">Occupation *</label>
          <div className="relative">
            <select name="occupation" value={data.occupation || ''} onChange={handle} className="select-field" required>
              <option value="">Select Occupation</option>
              {OCCUPATIONS.map(o => <option key={o} value={o}>{o}</option>)}
            </select>
            <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-purple-400">▾</div>
          </div>
        </div>
      </div>

      <div>
        <label className="block text-purple-300 text-sm mb-2">Email Address (Optional)</label>
        <input
          name="email"
          value={data.email || ''}
          onChange={handle}
          placeholder="yourname@email.com"
          className="input-field"
          type="email"
        />
      </div>
    </div>
  );
}
