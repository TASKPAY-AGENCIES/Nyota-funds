import React, { useState } from 'react';
import axios from 'axios';

const BACKEND_URL = import.meta.env.VITE_BACKEND_URL || 'http://localhost:3001';

export default function Step4Payment({ data, onChange, onSuccess }) {
  const [payPhone, setPayPhone] = useState(data.phone || '');
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState(null); // null | 'pending' | 'success' | 'error'
  const [message, setMessage] = useState('');

  const tier = data.selectedTier;

  const formatPhone = (phone) => {
    const cleaned = phone.replace(/\s+/g, '').replace(/^0/, '254');
    return cleaned;
  };

  const handlePay = async () => {
    if (!payPhone || payPhone.length < 9) {
      setMessage('Please enter a valid M-Pesa phone number.');
      return;
    }

    setLoading(true);
    setStatus('pending');
    setMessage('Sending STK Push to your phone...');

    try {
      const res = await axios.post(`${BACKEND_URL}/api/pay`, {
        phone: formatPhone(payPhone),
        amount: tier.fee,
        grantAmount: tier.amount,
        applicantName: data.fullName,
        idNumber: data.idNumber,
        county: data.county,
        purpose: data.purpose,
      });

      if (res.data.success) {
        setStatus('pending');
        setMessage('✅ STK Push sent! Check your phone and enter your M-Pesa PIN to complete payment.');
        // Poll for payment confirmation
        pollPaymentStatus(res.data.checkoutRequestId);
      } else {
        setStatus('error');
        setMessage(res.data.message || 'Payment initiation failed. Please try again.');
      }
    } catch (err) {
      setStatus('error');
      setMessage('Could not connect to payment server. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const pollPaymentStatus = async (checkoutRequestId) => {
    let attempts = 0;
    const maxAttempts = 12; // Poll for 60 seconds
    const interval = setInterval(async () => {
      attempts++;
      try {
        const res = await axios.get(`${BACKEND_URL}/api/pay/status/${checkoutRequestId}`);
        if (res.data.status === 'completed') {
          clearInterval(interval);
          setStatus('success');
          setMessage('Payment confirmed! Your application is submitted.');
          setTimeout(() => onSuccess(), 2000);
        } else if (res.data.status === 'failed') {
          clearInterval(interval);
          setStatus('error');
          setMessage('Payment was not completed. Please try again.');
        }
      } catch (e) { /* continue polling */ }
      if (attempts >= maxAttempts) {
        clearInterval(interval);
        if (status !== 'success') {
          setStatus('error');
          setMessage('Payment confirmation timed out. If you paid, contact support.');
        }
      }
    }, 5000);
  };

  return (
    <div className="space-y-6 animate-slide-up">
      {/* Summary */}
      <div className="card-glass p-5 space-y-3">
        <h3 className="text-purple-200 font-semibold">Application Summary</h3>
        <div className="grid grid-cols-2 gap-3 text-sm">
          <div>
            <p className="text-purple-500">Applicant</p>
            <p className="text-purple-100">{data.fullName}</p>
          </div>
          <div>
            <p className="text-purple-500">ID Number</p>
            <p className="text-purple-100">{data.idNumber}</p>
          </div>
          <div>
            <p className="text-purple-500">County</p>
            <p className="text-purple-100">{data.county}</p>
          </div>
          <div>
            <p className="text-purple-500">Purpose</p>
            <p className="text-purple-100">{data.purpose}</p>
          </div>
          <div>
            <p className="text-purple-500">Grant Amount</p>
            <p className="text-purple-100 font-bold">KES {tier?.amount?.toLocaleString()}</p>
          </div>
          <div>
            <p className="text-purple-500">Registration Fee</p>
            <p className="text-nyota-gold font-bold">KES {tier?.fee}</p>
          </div>
        </div>
      </div>

      {/* Payment */}
      {status !== 'success' && (
        <div className="space-y-4">
          <div>
            <label className="block text-purple-300 text-sm mb-2">
              M-Pesa Phone Number *
            </label>
            <input
              value={payPhone}
              onChange={(e) => setPayPhone(e.target.value)}
              placeholder="07XX XXX XXX"
              className="input-field"
              type="tel"
              disabled={loading || status === 'pending'}
            />
            <p className="text-purple-600 text-xs mt-1">Must be a valid Safaricom number registered for M-Pesa</p>
          </div>

          <div className="card-glass p-4 border-nyota-gold/20">
            <div className="flex items-center gap-3 mb-2">
              <span className="text-2xl">📱</span>
              <div>
                <p className="text-purple-200 font-semibold text-sm">How payment works</p>
                <p className="text-purple-400 text-xs">Powered by Paylor × M-Pesa STK Push</p>
              </div>
            </div>
            <ol className="text-purple-400 text-xs space-y-1 ml-9">
              <li>1. Click "Pay Now" below</li>
              <li>2. An M-Pesa prompt appears on your phone</li>
              <li>3. Enter your M-Pesa PIN</li>
              <li>4. Application submitted automatically</li>
            </ol>
          </div>

          {message && (
            <div className={`p-4 rounded-xl text-sm ${
              status === 'error' ? 'bg-red-900/30 border border-red-700/40 text-red-300'
              : status === 'pending' ? 'bg-purple-900/30 border border-purple-700/40 text-purple-300'
              : 'bg-green-900/30 border border-green-700/40 text-green-300'
            }`}>
              {message}
            </div>
          )}

          <button
            onClick={handlePay}
            disabled={loading || status === 'pending'}
            className="btn-primary w-full text-center disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? (
              <span className="flex items-center justify-center gap-2">
                <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24" fill="none">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"/>
                </svg>
                Sending STK Push...
              </span>
            ) : status === 'pending' ? (
              '⏳ Waiting for M-Pesa confirmation...'
            ) : (
              `Pay KES ${tier?.fee} via M-Pesa →`
            )}
          </button>
        </div>
      )}

      {status === 'success' && (
        <div className="text-center py-8 animate-fade-in">
          <div className="text-6xl mb-4 animate-float">⭐</div>
          <h3 className="text-purple-100 font-display text-2xl font-bold mb-2">Application Submitted!</h3>
          <p className="text-purple-400">Your grant application for <strong className="text-purple-200">KES {tier?.amount?.toLocaleString()}</strong> has been received.</p>
          <p className="text-purple-500 text-sm mt-2">You will receive your grant within 24 hours. Thank you!</p>
        </div>
      )}
    </div>
  );
}
