import { Link } from 'react-router-dom'

export default function Navbar() {
  return (
    <nav className="fixed top-0 left-0 right-0 z-50 glass-dark px-6 py-4 flex items-center justify-between">
      <Link to="/" className="flex items-center gap-2">
        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-500 to-purple-700 flex items-center justify-center">
          <span className="text-white font-bold text-sm">N</span>
        </div>
        <span className="text-white font-bold text-lg tracking-wide">Nyota Funds</span>
      </Link>
      <div className="flex items-center gap-4">
        <a href="#how-it-works" className="text-purple-300 hover:text-white text-sm transition">How it Works</a>
        <a href="#tiers" className="text-purple-300 hover:text-white text-sm transition">Grant Tiers</a>
        <Link
          to="/apply"
          className="bg-purple-600 hover:bg-purple-500 text-white px-4 py-2 rounded-lg text-sm font-semibold transition"
        >
          Apply Now
        </Link>
      </div>
    </nav>
  )
}
