import React from 'react';
import { GRANT_PURPOSES } from '../data';

const PURPOSE_ICONS = {
  "Education & School Fees": "🎓",
  "Starting or Expanding a Business": "💼",
  "Medical Emergency": "🏥",
  "Housing & Rent": "🏠",
  "Agricultural Support": "🌾",
  "Funeral & Burial Expenses": "🕊️",
  "Food & Basic Needs": "🍽️",
  "Other": "✦",
};

export default function Step2Purpose({ data, onChange }) {
  const handle = (e) => onChange({ ...data, [e.target.name]: e.target.value });

  return (
    <div className="space-y-6 animate-slide-up">
      <div>
        <label className="block text-purple-300 text-sm mb-4">What is this grant for? *</label>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {GRANT_PURPOSES.map((purpose) => (
            <button
              key={purpose}
              type="button"
              onClick={() => onChange({ ...data, purpose })}
              className={`p-4 rounded-xl border text-left transition-all duration-300 ${
                data.purpose === purpose
                  ? 'border-purple-500 bg-purple-900/40 text-purple-100'
                  : 'border-purple-800/40 bg-purple-900/10 text-purple-400 hover:border-purple-700/60 hover:text-purple-300'
              }`}
            >
              <div className="text-2xl mb-2">{PURPOSE_ICONS[purpose]}</div>
              <div className="text-xs font-medium leading-tight">{purpose}</div>
            </button>
          ))}
        </div>
      </div>

      <div>
        <label className="block text-purple-300 text-sm mb-2">
          Describe your situation briefly *
        </label>
        <textarea
          name="description"
          value={data.description || ''}
          onChange={handle}
          rows={4}
          placeholder="Explain briefly why you need this grant and how it will help you..."
          className="input-field resize-none"
          required
        />
        <p className="text-purple-600 text-xs mt-1">{(data.description || '').length}/500 characters</p>
      </div>

      <div>
        <label className="block text-purple-300 text-sm mb-2">Number of Dependants</label>
        <div className="relative">
          <select name="dependants" value={data.dependants || ''} onChange={handle} className="select-field">
            <option value="">Select</option>
            {['0', '1', '2', '3', '4', '5', '6+'].map(n => (
              <option key={n} value={n}>{n} {n === '1' ? 'person' : 'people'}</option>
            ))}
          </select>
          <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-purple-400">▾</div>
        </div>
      </div>
    </div>
  );
}
