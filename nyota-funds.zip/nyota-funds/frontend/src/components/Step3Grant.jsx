import React from 'react';
import { GRANT_TIERS } from '../data';

const TIER_COLORS = [
  'from-slate-700 to-slate-600',
  'from-slate-600 to-slate-500',
  'from-purple-900 to-purple-800',
  'from-purple-800 to-purple-700',
  'from-purple-700 to-violet-700',
  'from-violet-700 to-violet-600',
  'from-violet-600 to-indigo-600',
  'from-indigo-600 to-blue-600',
  'from-blue-700 to-cyan-700',
  'from-cyan-700 to-teal-700',
  'from-amber-700 to-yellow-600',
  'from-yellow-500 to-amber-400',
];

export default function Step3Grant({ data, onChange }) {
  return (
    <div className="space-y-4 animate-slide-up">
      <p className="text-purple-400 text-sm">Select the grant amount you are applying for. A small registration fee applies.</p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-h-[420px] overflow-y-auto pr-1">
        {GRANT_TIERS.map((tier, idx) => {
          const selected = data.selectedTier?.id === tier.id;
          return (
            <button
              key={tier.id}
              type="button"
              onClick={() => onChange({ ...data, selectedTier: tier })}
              className={`relative p-4 rounded-xl border text-left transition-all duration-300 ${
                selected
                  ? 'border-purple-400 bg-purple-900/50 shadow-lg shadow-purple-900/50'
                  : 'border-purple-800/30 bg-purple-900/10 hover:border-purple-700/50'
              }`}
            >
              {tier.id === 12 && (
                <span className="absolute top-3 right-3 text-xs bg-nyota-gold/20 text-nyota-gold px-2 py-0.5 rounded-full">
                  ★ Top
                </span>
              )}
              <div className={`inline-block px-2 py-0.5 rounded text-xs font-medium bg-gradient-to-r ${TIER_COLORS[idx]} text-white mb-2`}>
                {tier.label}
              </div>
              <div className="flex items-end justify-between">
                <div>
                  <p className={`text-xl font-bold ${selected ? 'text-purple-100' : 'text-purple-300'}`}>
                    KES {tier.amount.toLocaleString()}
                  </p>
                  <p className="text-purple-500 text-xs mt-0.5">Registration: KES {tier.fee}</p>
                </div>
                {selected && (
                  <div className="w-6 h-6 bg-purple-500 rounded-full flex items-center justify-center">
                    <span className="text-white text-xs">✓</span>
                  </div>
                )}
              </div>
            </button>
          );
        })}
      </div>

      {data.selectedTier && (
        <div className="card-glass p-4 border-purple-500/40 animate-fade-in">
          <div className="flex justify-between items-center">
            <div>
              <p className="text-purple-300 text-sm">Selected Grant</p>
              <p className="text-purple-100 font-bold text-lg">KES {data.selectedTier.amount.toLocaleString()}</p>
            </div>
            <div className="text-right">
              <p className="text-purple-300 text-sm">Registration Fee</p>
              <p className="text-nyota-gold font-bold text-lg">KES {data.selectedTier.fee}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
